import { Proyecto } from './proyecto';

describe('Proyecto', () => {
  it('should create an instance', () => {
    expect(new Proyecto()).toBeTruthy();
  });
});
