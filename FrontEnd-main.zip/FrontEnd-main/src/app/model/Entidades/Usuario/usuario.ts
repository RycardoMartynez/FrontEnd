export class Usuario {
    id:number;
    nombreU:String;
    password:string;

    constructor(id:number, nombreU:String, password:string) {
        this.id = id;
        this.nombreU = nombreU;
        this.password = password;

    }    
}
