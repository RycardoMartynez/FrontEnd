import { Experiencia } from './experiencia';

describe('Experiencia', () => {
  it('should create an instance', () => {
    expect(new Experiencia()).toBeTruthy();
  });
});
