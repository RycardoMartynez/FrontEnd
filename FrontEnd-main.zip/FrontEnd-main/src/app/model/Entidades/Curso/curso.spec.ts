import { Curso } from './curso';

describe('Curso', () => {
  it('should create an instance', () => {
    expect(new Curso()).toBeTruthy();
  });
});
